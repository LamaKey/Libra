import React,{useState} from 'react';
import { Link }       from 'react-router-dom';
import TableToolbar   from '../../components/TableToolbar';
import PaginatedTable from '../../components/PaginatedTable';
import AddProductModal from './AddProductModal';
import SearchSelect,{Option} from '../../components/SearchSelect';
import { query }     from '../../utils/storage';
import { Product }   from './types';
import { Supplier }  from '../suppliers/types';
import Badge         from '../../components/Badge';
import { FiBox } from 'react-icons/fi';

export default function ProductsPage(){
  const [search,setSearch] = useState('');
  const [showAdd,setShowAdd] = useState(false);

  const [avail,setAvail] = useState('');
  const [loc,setLoc] = useState('');

  /* filtering helpers (unchanged) */
  const availOpts:Option[]=[
    {value:'',label:'All'},
    {value:'ok',label:'In-stock'},
    {value:'low',label:'Low stock'},
    {value:'out',label:'Out of stock'}
  ];
  const locations=Array.from(
     new Set(query<Product>('products')
       .map(p=>p.location)
       .filter(Boolean) as string[])
  );
  const locOpts:Option[]=[{value:'',label:'All'},
    ...locations.map(l=>({value:l,label:l}))
  ];

  const supplierMap=Object.fromEntries(
    query<Supplier>('suppliers').map(s=>[s.id,s.name])
  );

  const products=query<Product>('products')
    .filter(p=>{
      if(avail==='ok')  return !p.low&&p.qty>0;
      if(avail==='low') return p.low &&p.qty>0;
      if(avail==='out') return p.qty===0;
      return true;
    })
    .filter(p=>!loc || p.location===loc)
    .filter(p=>p.name.toLowerCase().includes(search.toLowerCase()));

  return(
    <>
      <TableToolbar
        title="Products"
        search={{value:search,onChange:setSearch,placeholder:'Search product'}}
        filters={<>
          <SearchSelect value={avail} onChange={setAvail} options={availOpts}/>
          <SearchSelect value={loc}   onChange={setLoc}   options={locOpts}/>
        </>}
        onAdd={()=>setShowAdd(true)}
        addLabel="Add Product"
        combinedFilters={{
          availability:{ value:avail,onChange:setAvail,options:availOpts },
          location:{ value:loc,onChange:setLoc,options:locOpts }
        }}
      />

      <PaginatedTable
        data={products}
        cols={[
          {
            key:'img', header:'Products', render:(p)=>(
              <Link to={`/products/${(p as Product).id}`} className="row-link">
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  {(p as Product).img
                    ? <img src={(p as Product).img}
                           style={{width:32,height:32,borderRadius:6,objectFit:'cover'}}/>
                    : <FiBox size={28} color="#9e9e9e"/>}
                  {(p as Product).name}
                </div>
              </Link>
            )
          },
          { key:'price',   header:'Buying Price' },
          { key:'qty',     header:'Quantity'     },
          { key:'location',header:'Location'     },
          { key:'suppliers', header:'Suppliers',
            render:(p)=> (p as Product).suppliers
                       .map(id=>supplierMap[id]||'Unknown')
                       .join(', ') },
          { key:'low', header:'Availability',
            render:(p)=>{
              const pr=p as Product;
              const tone=pr.qty===0?'error':pr.low?'warning':'success';
              const label=pr.qty===0?'Out of stock':pr.low?'Low stock':'In-stock';
              return <Badge tone={tone}>{label}</Badge>;
            }}
            
        ]}
      />

      <AddProductModal open={showAdd} onClose={()=>setShowAdd(false)}/>
    </>
  );
}
