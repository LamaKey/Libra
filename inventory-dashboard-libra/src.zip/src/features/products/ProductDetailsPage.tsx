import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import TableToolbar from '../../components/TableToolbar';
import Button from '../../components/Button';
import { query } from '../../utils/storage';
import { Product } from './types';
import EditProductModal from './EditProductModal';

export default function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>() as { id: string };
  const prod = query<Product>('products').find(p => p.id === id);
  const [showEdit, setShowEdit] = useState(false);

  if (!prod) return <p>Product not found.</p>;

  return (
    <>
      <TableToolbar
        title={prod.name}
        onAdd={() => setShowEdit(true)}
        addLabel="Edit"
      />

      <div style={{ display:'flex', gap:32, flexWrap:'wrap' }}>
        <img src={prod.img || '/placeholder.png'} style={{ width:240, borderRadius:12 }}/>
        <div style={{ flex:1, minWidth:260 }}>
          <h3>Primary Details</h3>
          <ul>
            <li>Product ID: {prod.id}</li>
            <li>Unit Weight: {prod.unitWeight} g</li>
            <li>Quantity: {prod.qty}</li>
            <li>Location: {prod.location}</li>
          </ul>
        </div>
      </div>

      <EditProductModal open={showEdit} onClose={()=>setShowEdit(false)} product={prod}/>
    </>
  );
}
