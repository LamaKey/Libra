export interface Product {
  id: string;
  name: string;
  price: number;
  unitWeight: number;
  qty: number;
  location?: string;
  img?: string;
  low: boolean;
  suppliers: string[];

  /* NEW — optional currency */
  currency?: string;          // e.g. "USD"
}
