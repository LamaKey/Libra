import React,{useState} from 'react';
import Modal from '../../components/Modal';
import SearchSelect,{Option} from '../../components/SearchSelect';
import { query,insert } from '../../utils/storage';
import { Supplier } from '../suppliers/types';
import { Product }  from './types';
import { fileToDataURL } from '../../utils/fileToDataURL';
import { required,positiveNumber } from '../../utils/validators';
import { v4 as uuid } from 'uuid';
import { generateAlertIfNeeded } from '../../utils/alerts';
import { branchOptions } from '../../utils/branchOptions';

export default function AddProductModal({open,onClose}:{open:boolean;onClose:()=>void}){
  const supplierOpts:Option[] = query<Supplier>('suppliers')
    .map(s=>({value:s.id,label:s.name}));

  const [img,setImg]=useState<string>();
  const [name,setName]=useState('');
  const [price,setPrice]=useState('');
  const [unitW,setUnitW]=useState('');
  const [qty,setQty]=useState('');
  const [location,setLoc]=useState('');
  const [suppliers,setSuppliers]=useState<string[]>([]);
  const [currency,setCurrency]=useState('USD');
  const [submitted,setSubmitted]=useState(false);

  const numberOnly=(s:string)=>s.replace(/[^0-9.]/g,'');

  const errors={
    name : required(name),
    price: required(price)||positiveNumber(price),
    unitW: required(unitW)||positiveNumber(unitW),
    qty  : required(qty)||positiveNumber(qty),
    suppliers: suppliers.length?'':'Select ≥1 supplier'
  };
  const isValid=Object.values(errors).every(e=>!e);

  const pickImg=async(e:React.ChangeEvent<HTMLInputElement>)=>{
    if(e.target.files?.[0]) setImg(await fileToDataURL(e.target.files[0]));
  };

  const save=()=>{
    setSubmitted(true);
    if(!isValid) return;

    const rec:Product={
      id:uuid(),
      name,
      price:+price,
      unitWeight:+unitW,
      qty:+qty,
      location,
      img,
      low:+qty<=10,
      suppliers,     
      currency
    };
    insert('products',rec);
    generateAlertIfNeeded(rec);
    onClose();
  };

  return(
    <Modal open={open} title="New Product" onClose={onClose} width={520}
           onSubmit={save} submitLabel="Add product">
      <label>Image<input type="file" accept="image/*" onChange={pickImg}/></label>

      <label>Product name*
        <input placeholder="Enter product name" value={name}
               onChange={e=>setName(e.target.value)}/>
        {submitted&&errors.name&&<small className="err">{errors.name}</small>}
      </label>

      <label>Buying price*
        <input placeholder="0.00" value={price}
               onChange={e=>setPrice(numberOnly(e.target.value))}/>
        {submitted&&errors.price&&<small className="err">{errors.price}</small>}
      </label>

      <label>Unit weight (g)*
        <input placeholder="e.g. 50" value={unitW}
               onChange={e=>setUnitW(numberOnly(e.target.value))}/>
        {submitted&&errors.unitW&&<small className="err">{errors.unitW}</small>}
      </label>

      <label>Quantity*
        <input placeholder="e.g. 100" value={qty}
               onChange={e=>setQty(e.target.value.replace(/\D/g,''))}/>
        {submitted&&errors.qty&&<small className="err">{errors.qty}</small>}
      </label>

      <label>Location
        <SearchSelect
          value={location}
          onChange={setLoc}
          options={branchOptions()}
          placeholder="Select branch"
        />
      </label>

      <label>Suppliers*
        <SearchSelect
          value={suppliers}
          onChange={setSuppliers}
          options={supplierOpts}
          multi
          placeholder="Select suppliers"
        />
        {submitted&&errors.suppliers&&<small className="err">{errors.suppliers}</small>}
      </label>

      <label>Currency
        <SearchSelect
          value={currency}
          onChange={setCurrency}
          options={[{value:'USD',label:'USD'},{value:'EUR',label:'EUR'},{value:'GBP',label:'GBP'}]}
        />
      </label>
    </Modal>
  );
}
