import styles from './SummaryCard.module.css';

export default function SummaryCard({
  icon, value, label, onClick
}: { icon: React.ReactNode; value: number; label: string; onClick?: () => void }) {
  return (
    <button className={styles.card} onClick={onClick}>
      {icon}
      <span className={styles.value}>{value}</span>
      <span className={styles.label}>{label}</span>
    </button>
  );
}
