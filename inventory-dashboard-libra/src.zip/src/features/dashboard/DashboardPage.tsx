import React from 'react';
import styles from './DashboardPage.module.css';
import { useLowStock, useNormalStock } from './hooks';
import StockCard from './StockCard';
import RoomsCarousel from './RoomsCarousel';

/* ▶︎ icons from react-icons */
import { FiPackage, FiInbox, FiAlertTriangle } from 'react-icons/fi';

const SummaryCard = ({
  icon,
  value,
  label
}: {
  icon: React.ReactElement;
  value: number;
  label: string;
}) => (
  <div className={styles.summaryCard}>
    {icon}
    <div className={styles.sumValue}>{value}</div>
    <span className={styles.sumLabel}>{label}</span>
  </div>
);

export default function DashboardPage() {
  const low = useLowStock();
  const stock = useNormalStock();

  return (
    <div className={styles.page}>
      {/* ─ Inventory summary ─ */}
      <section className={styles.summary}>
        <SummaryCard
          icon={<FiPackage size={28} />}
          value={868}
          label="Quantity in Hand"
        />
        <SummaryCard
          icon={<FiInbox size={28} />}
          value={200}
          label="To be received"
        />
        <SummaryCard
          icon={<FiAlertTriangle size={28} color="#d32f2f" />}
          value={low.length}
          label="Alerts"
        />
      </section>

      {/* ─ Rooms ─ */}
      <RoomsCarousel />

      {/* ─ Stock & Low Stock ─ */}
      <section className={styles.stockRow}>
        <div className={styles.block}>
          <header>
            <span>Stock</span>
            <a href="/inventory">See all</a>
          </header>
          <div className={styles.grid}>
            {stock.slice(0, 6).map((p) => (
              <StockCard key={p.id} data={p} />
            ))}
          </div>
        </div>

        <div className={styles.block}>
          <header>
            <span>Low Quantity Stock</span>
            <a href="/inventory?filter=low">See all</a>
          </header>
          <div className={styles.grid}>
            {low.slice(0, 6).map((p) => (
              <StockCard key={p.id} data={p} low />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
