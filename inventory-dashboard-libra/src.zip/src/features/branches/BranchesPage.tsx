import React,{useState} from 'react';
import TableToolbar   from '../../components/TableToolbar';
import PaginatedTable from '../../components/PaginatedTable';
import AddBranchModal from './AddBranchModal';
import { query }     from '../../utils/storage';
import { Branch }    from './types';
import { FiMapPin }  from 'react-icons/fi';

export default function BranchesPage(){
  const [search,setSearch]=useState('');
  const [showAdd,setShowAdd]=useState(false);

  const branches=query<Branch>('branches')
    .filter(b=>b.name.toLowerCase().includes(search.toLowerCase()));

  return(
    <>
      <TableToolbar
        title="Manage Branch"
        search={{value:search,onChange:setSearch,placeholder:'Search branch'}}
        onAdd={()=>setShowAdd(true)}
        addLabel="Add Branch"
      />

      <PaginatedTable
        data={branches}
        cols={[
          { key:'img', header:'', render:(b:Branch)=>
              b.img
               ? <img src={b.img} style={{width:32,height:32,borderRadius:6}}/>
               : <FiMapPin size={28} color="#1976d2"/>},
          { key:'name',   header:'Store Name'},
          { key:'address',header:'Address'},
          { key:'street', header:'Street'},
          { key:'contact',header:'Contact'}
        ]}
      />

      <AddBranchModal open={showAdd} onClose={()=>setShowAdd(false)}/>
    </>
  );
}
