import React,{useState} from 'react';
import TableToolbar   from '../../components/TableToolbar';
import PaginatedTable from '../../components/PaginatedTable';
import AddOrderModal  from './AddOrderModal';
import SearchSelect,{Option} from '../../components/SearchSelect';
import { query }     from '../../utils/storage';
import { Order }     from './types';
import { daysUntil } from '../../utils/daysUntil';

export default function OrdersPage(){
  const [search,setSearch]=useState('');
  const [showAdd,setShowAdd]=useState(false);

  /* ------- currency filter ------- */
  const currencies=Array.from(new Set(query<Order>('orders').map(o=>o.currency)));
  const curOpts:Option[]=[{value:'',label:'All'},...currencies.map(c=>({value:c,label:c}))];
  const [cur,setCur]=useState<string>('');

  /* ------- supplier filter ------- */
  const suppliers=Array.from(new Set(query<Order>('orders').map(o=>o.supplier)));
  const suppOpts:Option[]=[{value:'',label:'All'},...suppliers.map(s=>({value:s,label:s}))];
  const [supp,setSupp]=useState<string>('');

  /* ------- data -------- */
  const orders=query<Order>('orders')
    .filter(o=>(!cur || o.currency===cur))
    .filter(o=>(!supp|| o.supplier===supp))
    .filter(o=>o.product.toLowerCase().includes(search.toLowerCase()));

  return(
    <>
      <TableToolbar
        title="Orders"
        search={{value:search,onChange:setSearch,placeholder:'Search orders'}}
        filters={
          <>
            <SearchSelect
              value={cur}
              onChange={setCur}
              options={curOpts}
              placeholder="Currency"
            />
            <SearchSelect
              value={supp}
              onChange={setSupp}
              options={suppOpts}
              placeholder="Supplier"
            />
          </>
        }
        onAdd={()=>setShowAdd(true)}
        addLabel="Add Order"
      />

      <PaginatedTable
        data={orders}
        cols={[
          {key:'product', header:'Products'},
          {key:'value',   header:'Order Value'},
          {key:'qty',     header:'Quantity'},
          {key:'id',      header:'Order ID'},
          {key:'delivery',header:'Expected Delivery',
            render:(o)=>{
              const d=(o as Order).delivery;
              const days=daysUntil(d);
              return days>=0?`In ${days} day${days!==1?'s':''}`
                            :`${Math.abs(days)} day${days!==-1?'s':''} ago`;
            }}
        ]}
      />

      <AddOrderModal open={showAdd} onClose={()=>setShowAdd(false)}/>
    </>
  );
}
