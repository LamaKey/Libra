import React,{useState} from 'react';
import TableToolbar   from '../../components/TableToolbar';
import PaginatedTable from '../../components/PaginatedTable';
import SearchSelect   from '../../components/SearchSelect';
import AddRoomModal   from './AddRoomModal';
import { query }      from '../../utils/storage';
import { Room }       from './types';
import { useNavigate }from 'react-router-dom';

export default function RoomsPage(){
  const navigate = useNavigate();
  const [search,setSearch]=useState('');
  const [showAdd,setShowAdd]=useState(false);
  const locations = Array.from(new Set(query<Room>('rooms').map(r=>r.location)));
  const [locFilter,setLocFilter]=useState<string>('');

  const rooms=query<Room>('rooms')
    .filter(r=>!locFilter||r.location===locFilter)
    .filter(r=>r.name.toLowerCase().includes(search.toLowerCase()));

  return(
    <>
      <TableToolbar
        title="Rooms"
        search={{value:search,onChange:setSearch,placeholder:'Search room'}}
        filters={
          <SearchSelect
            value={locFilter}
            onChange={setLocFilter}
            options={[{value:'',label:'All'},...locations.map(l=>({value:l,label:l}))]}
            placeholder="Filter by location"
          />
        }
        onAdd={()=>setShowAdd(true)}
        addLabel="Add Room"
      />

      <PaginatedTable
        cols={[
          {key:'name',header:'Rooms'},
          {key:'location',header:'Location'},
          {key:'scales',header:'Scales'},
          {key:'alerts',header:'Alerts',
            render:(r)=>{
              const cnt=(r as Room).alerts;
              const colour=cnt===0?'var(--color-success-600)'
                           :cnt<=5?'var(--color-warning-600)'
                                  :'var(--color-error-600)';
              return <span style={{color:colour,fontWeight:600}}>{cnt||'No'} Alerts</span>;
            }}
        ]}
        data={rooms}
        onRowClick={r=>navigate(`/rooms/${r.id}`)}
      />

      <AddRoomModal open={showAdd} onClose={()=>setShowAdd(false)}/>
    </>
  );
}
