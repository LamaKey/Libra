import React from 'react';
import styles from './ScaleTile.module.css';
export default function ScaleTile({ label, low }: { label: string; low: boolean }) {
  return (
    <div className={styles.tile}>
      <div className={styles.icon}>{label[0]}</div>
      <span>{label}</span>
      {low && <span className={styles.badge}>!</span>}
    </div>
  );
}
