import React from 'react';
import { DndContext, useDroppable, useDraggable, DragEndEvent } from '@dnd-kit/core';
import { restrictToParentElement } from '@dnd-kit/modifiers';
import { snap, CELL } from '../../utils/gridSnap';
import { query, update } from '../../utils/storage';
import { Scale } from './types';
import ScaleTile from './ScaleTile';
import { Product } from '../products/types';

function DraggableScale({ scale }: { scale: Scale }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: scale.id, data: scale
  });
  const style = {
    transform: transform
      ? `translate3d(${transform.x}px,${transform.y}px,0)`
      : undefined,
    left: scale.x,
    top: scale.y
  };
  const products = query<Product>('products');
  const prod = products.find(p => p.id === scale.productId);

  return (
    <div ref={setNodeRef} {...listeners} {...attributes} style={style} className="absolute">
      <ScaleTile label={prod?.name ?? 'Scale'} low={scale.alerts ? scale.alerts : false}/>
    </div>
  );
}

export default function ScaleCanvas({ roomId }: { roomId: string }) {
  const scales = query<Scale>('scales').filter(s => s.roomId === roomId);

  const savePos = (e: DragEndEvent) => {
    const s = e.active.data.current as Scale;
    if (!e.delta) return;
    update<Scale>('scales', s.id, {
      x: snap(s.x + e.delta.x),
      y: snap(s.y + e.delta.y)
    });
  };

  const { setNodeRef } = useDroppable({ id: 'canvas' });

  return (
    <DndContext onDragEnd={savePos} modifiers={[restrictToParentElement]}>
      <div ref={setNodeRef}
        style={{ width: 12*CELL, height: 12*CELL, position:'relative',
                 backgroundSize:`${CELL}px ${CELL}px`,
                 backgroundImage:'linear-gradient(to right,#eee 1px,transparent 1px),'
                               +'linear-gradient(to bottom,#eee 1px,transparent 1px)',
                 border:'1px solid #ddd',borderRadius:12 }}>

        {scales.map(s => <DraggableScale key={s.id} scale={s} />)}
      </div>
    </DndContext>
  );
}
