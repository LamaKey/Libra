export interface Room {
    id: string;
    name: string;
    location: string;
    alerts: number;
    scales: number;
    icon?: string;
  }
  export interface Scale {
    id: string;
  
    /* free-hand position inside the room */
    x: number;
    y: number;
  
    /* room the scale sits in */
    roomId: string;
  
    /* product weighed by this scale */
    productId: string;          // ← NEW
  
    /* optional thumbnail */
    img?: string;
    alerts?: boolean;
  }
  