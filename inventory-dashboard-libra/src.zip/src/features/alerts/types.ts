export interface Alert {
    id: string;
    productId: string;
    message: string;
    date: string;
  }
  