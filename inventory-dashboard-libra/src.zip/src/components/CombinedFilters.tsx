import React, { useState } from 'react';
import SearchSelect, { Option } from './SearchSelect';
import styles from './CombinedFilters.module.css';

interface Props {
  availability: { value: string; onChange: (v: string) => void; options: Option[] };
  location?:   { value: string; onChange: (v: string) => void; options: Option[] };
}
export default function CombinedFilters({ availability, location }: Props) {
  const [open, setOpen] = useState(false);
  return (
    <div className={styles.wrap}>
      <button type="button" onClick={() => setOpen(!open)}>Filters ▾</button>
      {open && (
        <div className={styles.pop}>
          <label>Availability
            <SearchSelect {...availability} />
          </label>
          {location && (
            <label>Location
              <SearchSelect {...location} />
            </label>
          )}
        </div>
      )}
    </div>
  );
}
